const express = require("express");
const session = require("express-session");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "CHANGE_THIS_PASSWORD";
const SESSION_SECRET = process.env.SESSION_SECRET || "CHANGE_THIS_SESSION_SECRET";

const dataDir = path.join(__dirname, "data");
const uploadDir = path.join(__dirname, "public", "uploads");
fs.mkdirSync(uploadDir, { recursive: true });
const dbFile = path.join(dataDir, "events.json");
if (!fs.existsSync(dbFile)) fs.writeFileSync(dbFile, "[]");

const readEvents = () => JSON.parse(fs.readFileSync(dbFile, "utf8"));
const saveEvents = events => fs.writeFileSync(dbFile, JSON.stringify(events, null, 2));

const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, uploadDir),
  filename: (_, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${Date.now()}-${Math.random().toString(36).slice(2)}${ext}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (_, file, cb) => {
    const ok = /image\/(jpeg|png|webp|gif)/.test(file.mimetype);
    cb(ok ? null : new Error("Only image files are allowed."));
  }
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 1000 * 60 * 60 * 8 }
}));
app.use(express.static(path.join(__dirname, "public")));

function adminOnly(req, res, next) {
  if (req.session.isAdmin) return next();
  res.status(401).json({ error: "Unauthorized" });
}

app.get("/api/events", (_, res) => res.json(readEvents()));

app.post("/api/login", (req, res) => {
  if (!req.body.password || req.body.password !== ADMIN_PASSWORD)
    return res.status(401).json({ error: "Incorrect password." });
  req.session.isAdmin = true;
  res.json({ ok: true });
});

app.post("/api/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get("/api/me", (req, res) => res.json({ admin: !!req.session.isAdmin }));

app.post("/api/events", adminOnly, upload.single("image"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "Please select an image." });
  const events = readEvents();
  const item = {
    id: Date.now().toString(),
    title: (req.body.title || "Previous Event").trim().slice(0, 120),
    caption: (req.body.caption || "").trim().slice(0, 250),
    image: `/uploads/${req.file.filename}`,
    createdAt: new Date().toISOString()
  };
  events.unshift(item);
  saveEvents(events);
  res.json(item);
});

app.delete("/api/events/:id", adminOnly, (req, res) => {
  const events = readEvents();
  const item = events.find(x => x.id === req.params.id);
  if (!item) return res.status(404).json({ error: "Event not found." });
  const filename = path.basename(item.image);
  const file = path.join(uploadDir, filename);
  if (fs.existsSync(file)) fs.unlinkSync(file);
  saveEvents(events.filter(x => x.id !== req.params.id));
  res.json({ ok: true });
});

app.use((err, req, res, next) => {
  if (err) res.status(400).json({ error: err.message || "Upload failed." });
  else next();
});

app.listen(PORT, () => console.log(`Maa Ramachandi site running on port ${PORT}`));

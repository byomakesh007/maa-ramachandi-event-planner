# Maa Ramachandi Event Planner — Full Stack

## Features
- Public luxury event-planner website
- Public Previous Events gallery
- Owner-only login
- Owner-only image upload/delete
- Event title and caption
- Uploaded images stored on the server

## Run locally
1. Install Node.js 18+.
2. Run `npm install`
3. Copy `.env.example` to `.env` and set a strong ADMIN_PASSWORD and SESSION_SECRET.
4. Run `npm start`
5. Open http://localhost:3000

## Production
Use HTTPS and set secure environment variables. For production hosting, use persistent storage for `public/uploads` and `data/events.json`, or replace these with cloud object storage and a database.
